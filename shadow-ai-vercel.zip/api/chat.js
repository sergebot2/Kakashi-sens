export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Méthode non autorisée" });
  }

  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_API_KEY) {
    return res.status(500).json({ error: "Clé API non configurée. Définir la variable d'environnement GEMINI_API_KEY." });
  }

  try {
    const { prompt } = req.body || {};
    if (!prompt || typeof prompt !== "string") {
      return res.status(400).json({ error: "Paramètre 'prompt' manquant ou invalide." });
    }

    // Appel à l'API Generative Language (Google Gemini)
    const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + encodeURIComponent(GEMINI_API_KEY);

    const payload = {
      // Structure minimale pour la génération
      "contents": [
        {
          "parts": [{ "text": prompt }]
        }
      ]
    };

    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!r.ok) {
      const text = await r.text();
      console.error("Erreur depuis Google API:", r.status, text);
      return res.status(502).json({ error: "Erreur depuis Google API: " + text });
    }

    const data = await r.json();
    const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Désolé, je n'ai pas pu générer de réponse.";

    return res.status(200).json({ reply });
  } catch (err) {
    console.error("Erreur interne:", err);
    return res.status(500).json({ error: err.message || "Erreur inconnue" });
  }
}
