# Shadow AI — Vercel deployment

Ce projet contient un frontend (index.html) et une fonction serverless Vercel (`/api/chat`) qui appelle l'API Generative Language (Gemini).

## Important — variables d'environnement

Avant de déployer, **ajoute la clé API** dans Vercel:

- Key: `GEMINI_API_KEY`
- Value: *Ta clé Google API (ex: AIza...)*

Ne pas mettre la clé directement dans le code.

## Déployer sur Vercel

1. Crée un dépôt Git (ou utilise l'upload ZIP).
2. Dans Vercel, crée un nouveau projet et connecte ton dépôt (ou glisse le ZIP).
3. Ajoute la variable d'environnement `GEMINI_API_KEY`.
4. Déploie.

## Fichiers

- `index.html` — frontend (app chat)
- `api/chat.js` — fonction serverless (lit `process.env.GEMINI_API_KEY`)
- `vercel.json` — configuration de déploiement
